/**
 * @file register_write_base.hpp
 * @author Marco van Eerden (mavaneerden@gmail.com)
 * @brief
 * @version 0.1
 * @date 2025-07-26
 *
 * TODO:
 */
#pragma once

#include "../registers/register_base.hpp"

namespace tsri::registers
{

/**
 * @brief TODO:
 *
 * @tparam PeripheralBaseAddress        Base address of the peripheral.
 * @tparam PeripheralBaseAddressOffset  Offest from theh peripheral base address.
 * @tparam ValueOnReset                 Value of the register after the CPU resets.
 * @tparam SupportsAtomicBitOperations  Whether the register supports atomic bit operations (xor, set, clear).
 * @tparam Fields                       Fields inside the register.
 */
template<
    utility::types::register_address_t PeripheralBaseAddress,
    utility::types::register_address_t PeripheralBaseAddressOffset,
    utility::types::register_value_t   ValueOnReset,
    typename... RegisterFields>
class register_write_base : register_base<PeripheralBaseAddress, PeripheralBaseAddressOffset, RegisterFields...>
{
private:
    using base_t = register_base<PeripheralBaseAddress, PeripheralBaseAddressOffset, RegisterFields...>;

public:
    register_write_base()                                              = delete;
    register_write_base(register_write_base&&)                         = delete;
    register_write_base(const register_write_base&)                    = delete;
    auto operator=(register_write_base&&) -> register_write_base&      = delete;
    auto operator=(const register_write_base&) -> register_write_base& = delete;
    ~register_write_base()                                             = delete;

    /**
     * @brief
     *
     * @param value
     */
    [[deprecated("In most cases you'll want to use set_fields_overwrite() instead!")]]
    static inline auto set(const utility::types::register_value_t value)
    {
        base_t::reference() = value;
    }

    /**
     * @brief
     */
    static inline auto reset()
    {
        base_t::reference() = ValueOnReset;
    }

    /**
     * @brief Set provided fields to the provided values. Overwrites existing register data outside the provied fields
     * with the value on reset.
     * Equivalent to REG = value1 << shift1 | value2 << shift2 | ... | valueN << shiftN | (~bitmask & value_on_reset);
     *
     * @tparam Fields Fields to set.
     * @param values  Values to set.
     */
    template<typename... Fields>
        requires(base_t::template are_fields_in_register<Fields...> && base_t::template are_fields_settable<Fields...>)
    static constexpr auto set_fields_overwrite(const typename Fields::value_t... values)
    {
        /* Reset value needs to be cleared at the field positions. Luckily this can be done at compile-time :) */
        static constexpr auto cleared_reset_value = ~(Fields::bitmask | ...) & ValueOnReset;

        /* Field values inside the register. */
        const auto field_values = (Fields::get_register_value_from_field_value(values) | ...);

        base_t::reference() = field_values | cleared_reset_value;
    }

#ifdef __thumb__
    /**
     * @brief
     *
     * @tparam Fields
     * @param values
     */
    template<typename... Fields>
        requires(base_t::template are_fields_in_register<Fields...> && base_t::template are_fields_settable<Fields...>)
    static constexpr auto set_fields_overwrite_asm(const typename Fields::value_t... values)
    {
        /* Maximum value of the immediate offset in the store instruction. */
        static constexpr uint32_t isa_offset_max_value = 124U;

        /* Reset value needs to be cleared at the field positions. Luckily this can be done at compile-time :) */
        static constexpr auto cleared_reset_value = ~(Fields::bitmask | ...) & ValueOnReset;

        /* Field values inside the register. */
        const auto field_values = (Fields::get_register_value_from_field_value(values) | ...);

        /* Register value that we will write to the register. */
        const auto register_value_to_set = field_values | cleared_reset_value;

        /* Use a store instruction with immediate offset if the offset fits in the immediate field.
         * Otherwise, use a register as the offset. This is a bit more expensive but can still potentially save some
         * code size.
         */
        // NOLINTNEXTLINE(bugprone-branch-clone)
        if constexpr (PeripheralBaseAddressOffset <= isa_offset_max_value)
        {
            asm volatile("str %[value], [%[base], %[offset]]\n\t"
                         :
                         : [value] "r"(register_value_to_set),
                           [base] "r"(PeripheralBaseAddress),
                           [offset] "i"(PeripheralBaseAddressOffset)
                         :);
        }
        else
        {
            asm volatile("str %[value], [%[base], %[offset]]\n\t"
                         :
                         : [value] "r"(register_value_to_set),
                           [base] "r"(PeripheralBaseAddress),
                           [offset] "r"(PeripheralBaseAddressOffset)
                         :);
        }
    }
#endif
};

}  // namespace tsri::registers
