/**
 * @file register_base.hpp
 * @author Marco van Eerden (mavaneerden@gmail.com)
 * @brief Base class for representation of hardware registers.
 * @version 0.1
 * @date 2025-07-25
 *
 * This file contains a templated base class for hardware registers.
 * This file serves as a base for the read-only, write-only and read-write registers.
 *
 * Each register has the following properties, which are known at compile time:
 *  - Peripheral base memory address;
 *  - Offset from the peripheral base memory address;
 *  - Value on reset;
 *  - Whether the register supports the RP2040 atomic bit set, clear and XOR functionality;
 *  - One or more fields.
 */
#pragma once

#include <bit>
#include <climits>
#include <type_traits>

#include "../utility/concepts.hpp"
#include "../utility/types.hpp"

namespace tsri::registers
{

template<typename BitPositionCandidate, typename... Fields>
concept bit_position = (std::is_same_v<BitPositionCandidate, typename Fields::bit_t> || ...) ||
                       std::is_convertible_v<BitPositionCandidate, utility::types::register_value_t>;

/* Number of bits in a register. */
inline constexpr utility::types::register_size_t num_bits_in_register =
    sizeof(utility::types::register_value_t) * CHAR_BIT;

/**
 * @brief Base class for hardware register representation.
 * Allows derived classes to read from and write to the register and its atomic counterparts (if supported).
 *
 * @tparam PeripheralBaseAddress        Base address of the peripheral.
 * @tparam PeripheralBaseAddressOffset  Offest from theh peripheral base address.
 * @tparam ValueOnReset                 Value of the register after the CPU resets.
 * @tparam SupportsAtomicBitOperations  Whether the register supports atomic bit operations (xor, set, clear).
 * @tparam Fields                       Fields inside the register.
 */
template<
    utility::types::register_address_t PeripheralBaseAddress,
    utility::types::register_address_t PeripheralBaseAddressOffset,
    typename... RegisterFields>
    requires utility::concepts::are_types_unique_v<RegisterFields...>
class register_base
{
public:
    register_base()                                        = delete;
    register_base(register_base&&)                         = delete;
    register_base(const register_base&)                    = delete;
    auto operator=(register_base&&) -> register_base&      = delete;
    auto operator=(const register_base&) -> register_base& = delete;
    ~register_base()                                       = delete;

private:
    /* Address offset for the atomic XOR on write, see Section 2.1.2 of the RP2040 datasheet. */
    static constexpr utility::types::register_address_t atomic_xor_offset = 0x1000U;
    /* Address offset for the atomic bitmask set on write, see Section 2.1.2 of the RP2040 datasheet. */
    static constexpr utility::types::register_address_t atomic_set_offset = 0x2000U;
    /* Address offset for the atomic bitmask clear on write, see Section 2.1.2 of the RP2040 datasheet. */
    static constexpr utility::types::register_address_t atomic_clear_offset = 0x3000U;

    /* Memory address of the register for normal read/write access. */
    static constexpr utility::types::register_address_t register_address =
        PeripheralBaseAddress + PeripheralBaseAddressOffset;
    /* Memory address of the register's atomic xor on write. */
    static constexpr utility::types::register_address_t register_address_atomic_xor =
        register_address + atomic_xor_offset;
    /* Memory address of the register's atomic bitmask set on write. */
    static constexpr utility::types::register_address_t register_address_atomic_set =
        register_address + atomic_set_offset;
    /* Memory address of the register's atomic bitmask clear on write. */
    static constexpr utility::types::register_address_t register_address_atomic_clear =
        register_address + atomic_clear_offset;

protected:
    /**
     * @brief
     *
     * @tparam Fields
     */
    template<typename... Fields>
    static constexpr bool are_fields_in_register =
        utility::concepts::are_types_unique_v<Fields...> &&
        (utility::concepts::is_type_in_list_v<Fields, RegisterFields...> && ...);

    /**
     * @brief
     *
     * @tparam Fields
     */
    template<typename... Fields>
    static constexpr bool are_fields_readable = (Fields::is_readable && ...);

    /**
     * @brief
     *
     * @tparam Fields
     */
    template<typename... Fields>
    static constexpr bool are_fields_settable = (Fields::is_settable && ...);

    /**
     * @brief
     *
     * @tparam Fields
     */
    template<typename... Fields>
    static constexpr bool are_fields_clearable = (Fields::is_clearable && ...);

    /**
     * @brief
     *
     * @tparam BitPosition
     */
    template<utility::types::register_size_t BitPosition>
    static constexpr bool is_bit_position_in_any_readable_field =
        ((RegisterFields::template is_position_in_field<BitPosition> && RegisterFields::is_readable) || ...);

    /**
     * @brief
     *
     * @tparam BitPosition
     */
    template<utility::types::register_size_t BitPosition>
    static constexpr bool is_bit_position_in_any_write_only_field =
        ((RegisterFields::template is_position_in_field<BitPosition> && RegisterFields::is_write_only) || ...);

    /**
     * @brief
     *
     * @tparam BitPosition
     */
    template<utility::types::register_size_t BitPosition>
    static constexpr bool is_bit_position_in_any_settable_field =
        ((RegisterFields::template is_position_in_field<BitPosition> && RegisterFields::is_settable) || ...);

    /**
     * @brief
     *
     * @tparam BitPosition
     */
    template<utility::types::register_size_t BitPosition>
    static constexpr bool is_bit_position_in_any_bit_clearable_field =
        ((RegisterFields::template is_position_in_field<BitPosition> && RegisterFields::is_bit_clearable) || ...);

    /**
     * @brief
     *
     * @tparam BitPosition
     */
    template<utility::types::register_size_t BitPosition>
    static constexpr bool is_bit_position_in_any_bit_togglable_field =
        ((RegisterFields::template is_position_in_field<BitPosition> && RegisterFields::is_bit_togglable) || ...);

    /* NOLINTBEGIN(readability-redundant-inline-specifier)
     * Inline is actually not redundant here. On GCC with -Og, these functions are not inlined without the inline or
     * constexpr specifier. Constexpr would work, but in my opinion it is not the correct keyword to use because this
     * function can never be evaluated at compile time: it is a cast to a volatile pointer. As such, I use inline here.
     */

    /**
     * @brief Returns a mutable reference to the hardware register, which should be used to write to the register in
     * derived classes.
     *
     * @return auto& Mutable reference to the register.
     */
    [[nodiscard]] static inline auto reference() -> auto&
    {
        return *std::bit_cast<utility::types::register_ptr_t>(register_address);
    }

    /**
     * @brief Returns a immutable reference to the hardware register, which should be used to read from the register in
     * derived classes.
     *
     * @return auto& Immutable reference to the register.
     */
    [[nodiscard]] static inline auto const_reference() -> const auto&
    {
        return *std::bit_cast<utility::types::register_ptr_t>(register_address);
    }

    /**
     * @brief Returns a mutable reference to the hardware register atomic xor on write, which should be used to write to
     * atomically XOR bits in the register in derived classes.
     *
     * @return auto& Mutable reference to the atomic xor on write register.
     */
    [[nodiscard]] static inline auto atomic_xor_reference() -> auto&
    {
        return *std::bit_cast<utility::types::register_ptr_t>(register_address_atomic_xor);
    }

    /**
     * @brief Returns a mutable reference to the hardware register atomic set bitmask on write, which should be used to
     * write to atomically set bits in the register in derived classes.
     *
     * @return auto& Mutable reference to the atomic set bitmask on write register.
     */
    [[nodiscard]] static inline auto atomic_set_reference() -> auto&
    {
        return *std::bit_cast<utility::types::register_ptr_t>(register_address_atomic_set);
    }

    /**
     * @brief Returns a mutable reference to the hardware register atomic clear bitmask on write, which should be used
     * to write to atomically clear bits in the register in derived classes.
     *
     * @return auto& Mutable reference to the atomic clear bitmask on write register.
     */
    [[nodiscard]] static inline auto atomic_clear_reference() -> auto&
    {
        return *std::bit_cast<utility::types::register_ptr_t>(register_address_atomic_clear);
    }

    // NOLINTEND(readability-redundant-inline-specifier)
};

}  // namespace tsri::registers
